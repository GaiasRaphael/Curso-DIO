from workout_api.categoria.models import CategoriaModel
from workout_api.centro_treinamento.models import CTModel
from workout_api.atleta.models import AtletaModel