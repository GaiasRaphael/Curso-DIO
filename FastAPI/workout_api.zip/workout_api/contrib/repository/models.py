from workout_api.categoria.models import CategoriaModel
from workout_api.atleta.models import AtletaModel
from workout_api.centro_treinamento.models import CTModel