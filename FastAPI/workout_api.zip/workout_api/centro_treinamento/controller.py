from uuid import uuid4
from fastapi import APIRouter, Body, HTTPException, status
from fastapi_pagination import add_pagination, Page, paginate
from pydantic import UUID4
from sqlalchemy import select

from workout_api.centro_treinamento.models import CTModel
from workout_api.centro_treinamento.schemas import CentroTreinamentoIn, CentroTreinamentoOut
from workout_api.contrib.dependencies import DatabaseDependency

router = APIRouter()

@router.post(
        '/', 
        summary='Criar um novo CT',
        status_code=status.HTTP_201_CREATED,
        response_model=CentroTreinamentoOut
         )
async def post(
    db_session: DatabaseDependency, 
    centro_treinamento_in: CentroTreinamentoIn = Body(...)
) -> CentroTreinamentoOut:
     
    centro_treinamento_out = CentroTreinamentoOut(id=uuid4(), **centro_treinamento_in.model_dump())
    centro_treinamento_model = CTModel(**centro_treinamento_out.model_dump())
    
    db_session.add(centro_treinamento_model)
    await db_session.commit()
    
    return centro_treinamento_out
    
@router.get(
        '/', 
        summary='Consultar todas os CTs',
        status_code=status.HTTP_200_OK,
        response_model=Page[CentroTreinamentoOut]
)
async def query(db_session: DatabaseDependency) -> list[CentroTreinamentoOut]:
    centros: list[CentroTreinamentoOut] = (await db_session.execute(select(CTModel))).scalars().all()
    return paginate(centros)
add_pagination(router) 

@router.get(
        '/{id}', 
        summary='Consultar um CT por id',
        status_code=status.HTTP_200_OK,
        response_model=CentroTreinamentoOut
)
async def query(id: UUID4, db_session: DatabaseDependency) -> list[CentroTreinamentoOut]:
    centro_treino: CentroTreinamentoOut = (await db_session.execute(select(CTModel).filter_by(id=id))).scalars().first()
    
    if not centro_treino:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f'CT não encontrado no id: {id}')
    
    return centro_treino