from workout_api.contrib.schemas import BaseSchemas
from typing import Annotated
from pydantic import UUID4, Field

class CentroTreinamentoIn(BaseSchemas):
    nome: Annotated[str, Field(description='Nome do Centro de Treinamento', example='CT King', max_length=50)]
    endereco: Annotated[str, Field(description='Endereco Centro de Treinamento', example='Rua X, 98', max_length=50)]
    proprietario: Annotated[str, Field(description='Proprietario do Centro de Treinamento', example='Joao', max_length=50)]

class CTAtleta(BaseSchemas):
    nome: Annotated[str, Field(description='Nome do Centro de Treinamento', example='CT King', max_length=50)]

class CentroTreinamentoOut(CentroTreinamentoIn):
    id: Annotated[UUID4, Field(description='Identificador do CT')]